# GACEB Scholar

Every file sits in this one folder. `organize.mjs` moves them into `src/` and `public/` on `npm run dev` and `npm run build`. Do not delete it. Do not add subfolders before upload.

## Supabase (do not rerun old payment or profile SQL)
1. SQL Editor: run `gaceb-new-tables.sql` once. It only adds announcements, the photo bucket, and the calendar. It does not change coins, profiles, payments, resources, or study-pdfs.
2. Run `gaceb-setup-check.sql` one numbered block at a time. In block 5, replace the email with yours, then run that block alone.
3. Log in on the site with that account. Post a test notice (text and a photo) and add a calendar date.

Old quiz links open Live Events. Social icons on Contact are ready; send the links when you have them.
